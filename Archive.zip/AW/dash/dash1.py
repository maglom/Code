# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.
import requests 
import json 
import datetime
import time
import plotly.express as px
from dash import Dash, html, dcc
import plotly.express as px
import pandas as pd

def get_price(antall,coin=11): 
    tidls = []
    verdils = []
    kurs = {}
    for i in range(antall):
        url = f'''https://api2.binance.com/api/v3/ticker/24hr'''
        response = requests.get(url) 
       
        # test if the respons was ok 
        assert response.status_code==200  
       
        dic = (json.dumps(response.json()))
        x = json.loads(dic)
        
        tid = datetime.datetime.now()
        tiden = tid.strftime('%Y-%m-%d %H:%M:%S') 
        
        tidls.append(tiden)
        verdils.append(x[coin]['lastPrice'])
        print(tidls[-1], verdils[-1])
        time.sleep(1)
    kurs['tid'] = tidls
    kurs['verdi'] = verdils

    return(kurs, x[coin]['symbol'])

app = Dash(__name__)

# assume you have a "long-form" data frame
# see https://plotly.com/python/px-arguments/ for more options

dic = get_price(10,coin=11)
fig = px.line(dic[0], x="tid", y="verdi")

app.layout = html.Div(children=[
    html.H1(children=f'{dic[1]} Kurs'),

    html.Div(children=f'''
        Her kan du se kursutviklingen i {dic[1]} den siste tiden!
    '''),

    dcc.Graph(
        id='Kurs',
        figure=fig
    )
])

if __name__ == '__main__':
    app.run_server(debug=False)