my_string = 'This iS a HEllO worLd test'

print(my_string.lower().count('l'))

