name = 'Magnus'
lastname = 'Greve'
course = 'Data'
no = '9'

print(f'My name is', '{name}', 'with last name', '{lastname}.', 'I am participating in the course', '{course}', 'There are', '{no}', 'candidates taking this course')
