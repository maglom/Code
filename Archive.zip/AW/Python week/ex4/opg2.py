from calendar import month_abbr


month_short = input('Input 3 char for month')

if month_short == 'Jan':
    print('January')
elif month_short == 'Feb':
    print('February')
elif month_short == 'Mar':
    print('March')
elif month_short == 'Apr':
    print('April')
elif month_short == 'May':
    print('May')
elif month_short == 'Jun':
    print('June')
elif month_short == 'Jul':
    print('July')
elif month_short == 'Aug':
    print('August')
elif month_short == 'Sep':
    print('September')
elif month_short == 'Nov':
    print('November')
elif month_short == 'Dec':
    print('December')
else:
    print('Unknown')