name = 'MAGNUS'
lastname = 'greve'
course = 'DATA ENGINEER AND ANALYTICS'
no = '9'

print(f'''My name is {name.capitalize()} with last name {lastname.capitalize()}.
 I am participating in the course {course.lower()} There are {no} candidates 
 taking this course''')
