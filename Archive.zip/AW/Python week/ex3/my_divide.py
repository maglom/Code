input1 = float(input('Input a int'))

input2 = float(input('Input another int'))

sum = input1 / input2

print(sum)