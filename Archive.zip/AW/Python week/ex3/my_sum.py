
'''2.  Create a calculator: 
a.  Make a program called my_sum.py. Use the “input” operation in 
python, and let the user specify two input, sum them together, and 
print the result. Double check that the math is correct. 
hint: make sure that the type of the values is float before adding 
them together. '''

input1 = float(input('Input a int'))

input2 = float(input('Input another int'))

sum = input1 + input2

print(sum)