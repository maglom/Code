var_1, var_2, var_3 = 1, 2, 3

var_1, var_2 = var_2, var_1
var_1
var_2

