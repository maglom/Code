for i in range(50,-1,-1):
    print(i)
