import math

initials = "MLG"
poptown = 15236
popearth = 7753000000
weekday = "saturday"
duration = "3 months"
pi = math.pi

print(f"""My initials are {initials}. Of an total population on earth of {popearth}, {poptown} people live in my hometown. 
Today is {weekday} and soon i will be attending a course which lasts for {duration}. FYI this is the number pi: {pi}.""")