# Sub exercise 1

print(345%12)

# Sub exercise 2

x = 5
y = 3
x = x * y
x = x - 5
print(x)

# Sub exercise 3

total = 37 - 6
left = total % 3
print(left)